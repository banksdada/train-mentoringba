# Fictional Stakeholder Meeting Notes — Online Banking Address Update

All content is fictitious training data. Business objective: allow authenticated
customers to request mailing-address changes online instead of calling the
contact centre. Reduce manual handling without compromising security or accuracy.

## Transcript

**Product Owner:** Customers should change their mailing address online.

**Operations Manager:** Today an agent verifies identity and updates the
profile after a call.

**Digital Banking Lead:** Display the current address and let customers submit
a new one.

**Security Representative:** Authentication is required; extra verification
may be needed.

**Integration Lead:** An existing Customer Profile API might support updates;
its contract is not confirmed.

**Operations Manager:** We must clearly distinguish successful and failed
changes.

## Decision log from the meeting

| Item | Status |
|---|---|
| Online address change | Confirmed business objective |
| Authentication | Confirmed requirement |
| Current address display | Requested, awaiting formal confirmation |
| Additional verification | Open decision |
| Address validation rules | Not defined |
| API contract/error handling | Not verified |
| Audit retention policy | Not defined |
| Call reduction target | Not measured |
