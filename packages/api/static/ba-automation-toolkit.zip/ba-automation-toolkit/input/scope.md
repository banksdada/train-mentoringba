# Proposed Scope — Online Banking Address Update

**Proposed in scope:** authenticated journey, current-address display and
new-address submission, service integration, error handling, and
audit-requirement discovery.

**Proposed out of scope:** phone/email changes, branch requests, bulk
migration.

Scope decisions require approval by the Product Owner before the
requirements baseline is accepted. Nothing in this file is confirmed until
signed off.
