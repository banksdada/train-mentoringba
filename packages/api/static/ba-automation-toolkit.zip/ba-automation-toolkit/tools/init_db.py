#!/usr/bin/env python3
"""Build the local demo database from data/setup.sql. Agent-agnostic."""
import pathlib
import sqlite3

ROOT = pathlib.Path(__file__).resolve().parent.parent
DB = ROOT / "data" / "banking_demo.db"
SQL = ROOT / "data" / "setup.sql"


def main() -> None:
    if DB.exists():
        DB.unlink()
    conn = sqlite3.connect(DB)
    conn.executescript(SQL.read_text(encoding="utf-8"))
    conn.close()
    print(f"created {DB}")


if __name__ == "__main__":
    main()
