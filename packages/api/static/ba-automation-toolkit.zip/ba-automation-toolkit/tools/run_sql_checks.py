#!/usr/bin/env python3
"""SELECT-only validation checks against the demo database.

Runs the three stage-4 checks from the playbook, compares actual vs
expected, prints PASS/FAIL, and flags the analyst-interpretation case.
Exit code 0 = all checks passed, 1 = any failure.
"""
import pathlib
import sqlite3
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
DB = ROOT / "data" / "banking_demo.db"

CHECKS = [
    {
        "name": "check-1 orphan audit records",
        "sql": """
            SELECT a.change_id, a.customer_id
            FROM address_change_audit a
            LEFT JOIN customers c ON a.customer_id = c.customer_id
            WHERE c.customer_id IS NULL
        """,
        "expected": [(5, 999)],
    },
    {
        "name": "check-2 status counts",
        "sql": """
            SELECT change_status, COUNT(*) AS total
            FROM address_change_audit
            GROUP BY change_status ORDER BY change_status
        """,
        "expected": [("FAILED", 1), ("PENDING", 1), ("SUCCESS", 3)],
    },
    {
        "name": "check-3 latest event by customer",
        "sql": """
            WITH ranked_changes AS (
              SELECT customer_id, requested_address, change_status,
                     ROW_NUMBER() OVER (
                       PARTITION BY customer_id
                       ORDER BY requested_at DESC, change_id DESC
                     ) AS rn
              FROM address_change_audit
            )
            SELECT customer_id, requested_address, change_status
            FROM ranked_changes WHERE rn = 1 ORDER BY customer_id
        """,
        "expected": [
            (101, "115 King St", "SUCCESS"),
            (102, "220 Queen St", "FAILED"),
            (104, "440 Yonge St", "PENDING"),
            (999, "999 Unknown St", "SUCCESS"),
        ],
    },
]


def main() -> int:
    conn = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
    failed = 0
    for check in CHECKS:
        rows = conn.execute(check["sql"]).fetchall()
        ok = rows == check["expected"]
        failed += 0 if ok else 1
        print(f"[{'PASS' if ok else 'FAIL'}] {check['name']}")
        if not ok:
            print(f"  expected: {check['expected']}")
            print(f"  actual:   {rows}")
    conn.close()

    print(
        "\nANALYST INTERPRETATION: the SUCCESS event for customer 101 "
        "(115 King St) does not match the address stored in customers "
        "(10 King St). Flag as an open question for architecture/process "
        "confirmation — not as a proven production defect."
    )
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
