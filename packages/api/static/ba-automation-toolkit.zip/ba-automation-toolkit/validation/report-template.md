# Validation Report Template

Use after each stage, and as the final cross-artifact audit (Stage 8).
The reviewer must be a fresh context (new session or different agent) —
never the same conversation that produced the artifacts.

Findings table:

| ID | Severity | Location (file + line) | Evidence | Impact | Corrective action | Owner | Status |
|---|---|---|---|---|---|---|---|
| F-001 | High/Med/Low | | | | | | Open |

Artifact verdicts — one of: **Ready** / **Ready with Conditions** / **Rework**

- [ ] Requirements register
- [ ] Clarification log
- [ ] User stories & AC
- [ ] Backlog publication (issue keys/cards/rows checked manually in the backend)
- [ ] Data dictionary / SQL checks
- [ ] API requirements
- [ ] UAT pack / execution register
- [ ] RTM

Reviewer prompt is Stage 8 in `PLAYBOOK.md`. Do not change files without approval.
