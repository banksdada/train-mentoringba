DROP TABLE IF EXISTS address_change_audit;
DROP TABLE IF EXISTS customers;

CREATE TABLE customers (
  customer_id INTEGER PRIMARY KEY,
  customer_name TEXT NOT NULL,
  mailing_address TEXT NOT NULL,
  postal_code TEXT NOT NULL,
  status TEXT NOT NULL
);

CREATE TABLE address_change_audit (
  change_id INTEGER PRIMARY KEY,
  customer_id INTEGER NOT NULL,
  requested_address TEXT NOT NULL,
  requested_postal_code TEXT NOT NULL,
  change_status TEXT NOT NULL,
  requested_at TEXT NOT NULL,
  FOREIGN KEY(customer_id) REFERENCES customers(customer_id)
);

INSERT INTO customers VALUES
(101,'Alex Morgan','10 King St','M5H 1A1','ACTIVE'),
(102,'Taylor Lee','20 Queen St','M5V 2B2','ACTIVE'),
(103,'Jordan Smith','30 Bay St','M5J 3C3','INACTIVE'),
(104,'Casey Brown','40 Yonge St','M4P 4D4','ACTIVE');

INSERT INTO address_change_audit VALUES
(1,101,'110 King St','M5H 1A2','SUCCESS','2026-10-01 10:00:00'),
(2,102,'220 Queen St','M5V 2B3','FAILED','2026-10-02 11:00:00'),
(3,104,'440 Yonge St','M4P 4D5','PENDING','2026-10-03 12:00:00'),
(4,101,'115 King St','M5H 1A3','SUCCESS','2026-10-04 13:00:00'),
(5,999,'999 Unknown St','M5X 9Z9','SUCCESS','2026-10-05 14:00:00');
