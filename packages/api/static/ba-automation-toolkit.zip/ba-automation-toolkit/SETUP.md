# Setup — Any Agent

Prerequisites: Node.js 20+ and npm, Python 3, a terminal, VS Code or any
editor. Optional: a publication backend (see `adapters/`), approved staging URL.
Backend access (e.g. Atlassian) requires organization approval.

The playbook's core loop (Stages 1–2, 4–5, 7–8) works with **zero MCP and zero
accounts**: one chat agent reading this folder is enough. Connections are
only needed for Stages 3 and 6 execution.

## 1. Your coding agent

| Agent | Start in this folder | Reads rules from | Skills support |
|---|---|---|---|
| Claude Code | `claude` | `CLAUDE.md` | `.claude/skills/` |
| Codex CLI | `codex` | `AGENTS.md` | `.agents/skills/` |
| opencode | `opencode` | `AGENTS.md` | `.agents/skills/` |
| Cursor | open folder | `AGENTS.md` / `CLAUDE.md` | rules only |
| VS Code Copilot | open folder | `AGENTS.md` | — |
| Gemini CLI | `gemini` | `GEMINI.md` (copy of AGENTS.md if needed) | — |

Any agent that pastes the PLAYBOOK prompt works. Model choice is yours — the
quality gates exist because no model is trustworthy unsupervised.

Claude Code install (reference path):
```bash
npm install -g @anthropic-ai/claude-code
claude --version && claude
```
Optional Anthropic plugins/marketplaces:
```bash
claude plugin marketplace add anthropics/knowledge-work-plugins
claude plugin install product-management@knowledge-work-plugins
claude plugin install data@knowledge-work-plugins
claude plugin marketplace add anthropics/skills
claude plugin install document-skills@anthropic-agent-skills
```

## 2. Publication backend (Stage 3 only) — pick one

| Backend | Cost | Setup |
|---|---|---|
| GitHub Issues — **recommended default** | Free (account students already have) | [adapters/github-issues.md](adapters/github-issues.md) |
| Trello | Free | [adapters/trello.md](adapters/trello.md) |
| Google Sheets → NativeTasks | Free plan | [adapters/google-sheets-nativetasks.md](adapters/google-sheets-nativetasks.md) |
| Jira + Confluence | Free sandbox / site | [adapters/atlassian.md](adapters/atlassian.md) |

Whichever you connect, test read-only first:
*"Show the projects/boards/spaces I can access. Do not create or update
anything."*

## 3. Browser automation (Stage 6 only)

Playwright MCP is the reference; any browser-capable agent tooling works
(Chrome DevTools MCP, Playwright test scripts, native browser tools).

| Agent | Add command / config |
|---|---|
| Claude Code | `claude mcp add playwright npx @playwright/mcp@latest` |
| Codex | `[mcp_servers.playwright] command = "npx" args = ["@playwright/mcp@latest"]` |
| Cursor / VS Code / opencode | merge the `playwright` entry from `mcp.example.json` |

Connectivity test (not banking UAT): open https://demo.playwright.dev/todomvc
and ask the agent to add two tasks and verify they appear.

## 4. Local database (Stage 4)

```bash
python3 tools/init_db.py
python3 tools/run_sql_checks.py
```
No MCP, no agent, no internet required.

## Verified upstream repositories

- Claude Code — https://github.com/anthropics/claude-code
- Anthropic Skills — https://github.com/anthropics/skills
- Knowledge Work Plugins — https://github.com/anthropics/knowledge-work-plugins
- Atlassian MCP Server — https://github.com/atlassian/atlassian-mcp-server
- Microsoft Playwright MCP — https://github.com/microsoft/playwright-mcp

CLI commands and plugin names evolve — if an install fails, follow the linked
repo for your installed version.
