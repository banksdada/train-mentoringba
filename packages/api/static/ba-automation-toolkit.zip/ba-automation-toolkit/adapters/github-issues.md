# Adapter: GitHub Issues (free, official MCP — recommended default)

Every student already has a GitHub account — this lab's repo is one. Issues
give you labels, milestones, links and an audit trail for £0, and GitHub's own
MCP server works with Claude, Copilot, Cursor, Codex and opencode.

## Connect

```bash
claude mcp add --transport http github https://api.githubcopilot.com/mcp/
```
Or official binary: `npx @modelcontextprotocol/server-github` (stdio) with a
fine-grained PAT scoped to the lab repo only (Issues: read+write). Merge into
other agents' MCP config the same way as `../mcp.example.json`.

Read-only test: *"List the labels and open issues in
banksdada/mentoringba-automation-toolkit. Create nothing."*

## Stage 3 mapping

| Playbook concept | GitHub object |
|---|---|
| Epic | Issue with `epic` label |
| User story | Issue, body = story + GWT AC, `Closes #`/`Related to #` links |
| Requirement IDs | Issue labels (`FR-003`, `US-001`) — created once on the repo |
| Blocked stories | `Status: Blocked` label + linked blocker issue |
| Requirements register | Discussion or file in `requirements/` (PR = Gate 1) |

## Why this is the best teaching backend

- Real issue keys = real traceability rows in Stage 7 (no invented IDs).
- The PR/merge flow shows students an approval gate that is enforced by the
  tool, not just promised by a prompt.
- Same repo as the toolkit → zero extra setup for students.

## Gates

Gate 1 = approve the requirements PR. Gate 2 = agent must print the exact
issue titles/labels it would create and wait for "go".
