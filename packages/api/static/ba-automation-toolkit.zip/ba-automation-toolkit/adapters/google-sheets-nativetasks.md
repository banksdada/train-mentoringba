# Adapter: NativeTasks ⇄ Google Sheets (assessed by AIOS)

**Verified direction (2026-11-01):** NativeTasks' Google Sheets integration is
**one-way out** — tasks (including completions) are pushed to a Google Sheet
in real time. There is **no public API or MCP** for creating tasks in
NativeTasks. So the system of record for *doing* work is NativeTasks, and the
system of record for *assessing* work is the synced sheet, which the AIOS
agent can read and annotate.

```
student/BA completes task in NativeTasks
        │  (integration, real-time, one-way)
        ▼
synced Google Sheet  ◀── shared with AIOS service account (Editor)
        │
        ▼
scripts/nativetasks-assess.py reads new completions,
assesses them against gate rules, writes results to a
separate AIOS_Evaluation tab (never edits the sync tab)
```

## One-time setup (account owner does this)

1. Create a sheet in the mentoringba Google account, e.g.
   `mentoringba-automation-sync`.
2. In NativeTasks → Integrations → Google Sheets, connect that sheet.
3. Share the sheet as **Editor** with
   `aios-bot@aios-credentials.iam.gserviceaccount.com`.
4. Give the agent the spreadsheet ID.

## Stage 3 mapping (backlog rows)

The lab's Backlog tab is written by the agent (append-only). Columns:

| Column | Content |
|---|---|
| A | Story ID (US-001…) |
| B | Title |
| C | Linked requirement IDs |
| D | Acceptance criteria (GWT, newline-separated) |
| E | Status: Draft / Blocked / Ready / Done |
| F | Gate 2 approved? (yes/no/date) |
| G | Notes / blockers (clarification Q refs) |

To move a backlog row into NativeTasks for execution, the human creates or
copies it there (no API exists). Completion flows back automatically.

## Assessment rules (what the runner checks per completed task)

- Story ID resolves to a Backlog row with `Gate 2 = yes` — otherwise
  **UNAPPROVED WORK**.
- Completion carries evidence (link, screenshot ref, or run record) —
  otherwise **NO EVIDENCE**.
- Requirement links present — otherwise **ORPHAN**.
- Verdicts: `Pass` / `Pass with conditions` / `Rework` / `Reject`, each with
  the failing rule cited. Verdicts are drafts for human sign-off (Gate 4).

## Limits to be honest about

- Task *creation* in NativeTasks stays manual (or via their form feature).
- No enforced permissions — assessment is the gate, not the tool.
- Sync timing must be spot-checked once per session; that check is itself a
  teaching moment about evidence.
