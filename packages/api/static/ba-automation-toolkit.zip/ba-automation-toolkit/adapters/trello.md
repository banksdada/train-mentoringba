# Adapter: Trello (free, no credit card)

Boards are enough for this lab: lists = backlog stages, cards = stories.
Trello's REST API works with any free account.

## Connect

Community MCP (pick one maintained server, e.g. `mcp-server-trello`):

```json
"trello": {
  "command": "npx",
  "args": ["-y", "mcp-server-trello"],
  "env": {
    "TRELLO_API_KEY": "<from https://trello.com/app-key>",
    "TRELLO_TOKEN": "<generated for your account>"
  }
}
```

No-MCP fallback: any agent that can run `curl` uses the REST API directly
(`POST /1/lists`, `POST /1/cards`). Keys stay in the agent's env/config, never
in prompts or the repo.

## Board setup (once, free account)

Board `BA-Automation-Lab` with lists:

`Backlog → Ready (Gate 1 passed) → In UAT → Done / Blocked`

## Stage 3 mapping

| Playbook concept | Trello object |
|---|---|
| Epic | Board label + list prefix, or a parent card |
| User story | Card title = `US-00x — <title>`; card description = GWT AC list |
| Requirement IDs | Card label or checklist line `FR-003` |
| Status (Draft/Blocked/Ready) | The list the card sits in |

## Gates

Gate 2 before any card is created; Gate 4 evidence = card cover screenshot or
checklist with the run record pasted in.
