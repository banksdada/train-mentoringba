# Adapter: Atlassian Jira + Confluence (enterprise path)

The guide's default. Costs nothing to learn but needs a Jira/Confluence site —
students can use a free Atlassian Cloud sandbox (up to 10 users, resets
periodically) or the RDI trial.

## Connect

```bash
claude mcp add --transport http atlassian https://mcp.atlassian.com/v2/mcp
```
Other agents: merge the `atlassian` entry from `../mcp.example.json` into the
agent's MCP config. Authorize via `/mcp` (Claude) or the agent's connector UI.

Read-only test: *"Show the Jira projects and Confluence spaces I can access.
Do not create or update anything."*

## Stage 3 mapping

| Playbook concept | Atlassian object |
|---|---|
| Epic | Issue type Epic |
| User story | Issue type Story, `Requirement_ID` in labels (e.g. `REQ-`/`FR-003`) |
| Acceptance criteria | Story description, "Acceptance Criteria" heading, GWT bullets |
| Requirements register | Confluence page, one per release |
| Clarification log | Confluence page table |

## Traceability hook

Labels carrying requirement IDs are what Stage 7 (RTM) reads back out of Jira.

## Gates

Gate 2 (publication approval) is non-negotiable here: never bulk-create before
one dry run that prints "what you would create" without writing.
