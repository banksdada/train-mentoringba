# The BA Automation Playbook — 8 Stages

Run every stage in **any** agent that reads this folder (Claude Code, Codex,
Cursor, Copilot, opencode, Windsurf, Gemini CLI). Prompts are plain text —
paste them in, or point the agent at a stage heading. The folder rules in
`AGENTS.md` / `CLAUDE.md` are picked up automatically.

Working order matters: each stage's output is the next stage's input. Stop at
every ⛔ checkpoint and get a human decision before continuing.

---

## Stage 1 — Requirements elicitation

> Use the ba-requirements skill (if your agent supports skills; otherwise this
> prompt is the skill).
> Read input/meeting-notes.md and input/scope.md.
> Extract objectives, stakeholders, FRs, NFR candidates, API/data candidates,
> scope, risks and dependencies.
> For every finding, cite the exact source.
> Label each item Confirmed, Proposed or Unresolved.
> Identify questions requiring stakeholder answers.
> Create the files: requirements/requirements-register.md,
> requirements/clarification-log.md, validation/requirements-review.md.
> No external writes.

⛔ **Checkpoint 1** — every assertion has source evidence or explicit draft
status. Stakeholder decisions exist for rules, scope and priorities before the
baseline is approved. Compare against `requirements/requirements-register.sample.md`.

## Stage 2 — User stories & acceptance criteria

> Read the reviewed requirements register.
> Create epics and INVEST user stories with IDs.
> Include linked requirement IDs, user benefit,
> Given/When/Then acceptance criteria, positive, negative and boundary
> scenarios, dependencies, and a Definition of Ready assessment.
> Mark unconfirmed behaviours for stakeholder review.
> Save to stories/user-stories.md.

Expected shape: `stories/user-stories.sample.md`. Criteria remain draft until
stakeholders confirm exact business and technical behaviors.

## Stage 3 — Backlog publication (choose a backend)

Pick one adapter in `adapters/` — the prompt below is the same for all:

| Backend | Cost | Best when |
|---|---|---|
| [GitHub Issues](adapters/github-issues.md) | Free | Default for students — real issue keys, enforced gates |
| [Trello](adapters/trello.md) | Free | Visual kanban preference |
| [Google Sheets → NativeTasks](adapters/google-sheets-nativetasks.md) | Free | Backlog where the team already works |
| [Atlassian Jira/Confluence](adapters/atlassian.md) | Free sandbox / paid site | Enterprise realism, the guide's default |

> Read reviewed stories and requirements.
> Using the connected backlog tool for my workspace:
> find the authorized project/board/sheet.
> Show a preview of epic/story titles, acceptance criteria, requirement
> mappings and duplicates. Do not write anything yet. Ask for approval.
> After approval create only the agreed items.
> Return actual issue keys / card IDs / row numbers.
> Update the local mappings with verified identifiers.

No connection available → save drafts locally and do not assert publication.

⛔ **Checkpoint 2** — verify the item type, story body, criteria, scope,
ownership and the actual key/card/row directly in the backend, by hand.

## Stage 4 — SQL data validation (no agent needed to run)

```bash
python3 tools/init_db.py
python3 tools/run_sql_checks.py
```

> Analyze data/setup.sql and the SQLite database data/banking_demo.db.
> Explain table relationships; create a data dictionary and a Mermaid ERD.
> Write SELECT-only validation queries. Execute locally if available,
> compare actual with expected, and record risks. Never change source records.
> Save to data/data-validation.md.

The dataset deliberately contains an orphan audit record and a reconciliation
question (customer 101's address). The runner expects: orphan
(change_id 5, customer_id 999); counts FAILED=1, PENDING=1, SUCCESS=3.
Flag mismatches as questions for confirmation — not as proven production defects.

## Stage 5 — API requirements

The meeting notes do **not** establish a real endpoint. An illustrative JSON
shape lives in `requirements/api-shape.example.json` — it is not a contract.

> Read approved FRs and any supplied OpenAPI specification.
> Document interface purpose, consumer/provider, methods/endpoints, fields,
> authentication, response codes, errors, timeouts, retry/idempotency,
> privacy and logging.
> Separate Confirmed, Proposed and Unknown.
> Never invent a production endpoint or confirmed response.
> Save to requirements/api-requirements.md.

⛔ **Checkpoint 3** — the API owner verifies the real OpenAPI/Swagger contract,
response mapping, authorization, failure handling, transaction state and
idempotency policy.

## Stage 6 — UAT generation & Playwright execution

Generate the pack with any agent:

> Read approved stories, AC and API requirements.
> Create a UAT pack with TC ID, mapped requirement, preconditions, test data,
> steps, expected result, actual result, status, evidence, defect and owner.
> Cover success, invalid/missing input, unauthenticated access, service
> failure, duplicate submission and pending updates where applicable.
> Mark open rules as Blocked. Save to uat/uat-test-cases.md.

Execution needs an approved staging URL — see `SETUP.md` for Playwright MCP /
browser automation per agent:

> Using browser automation against [APPROVED_STAGING_URL] only,
> with synthetic test users only. First confirm environment, test credentials,
> fixtures and executable cases. Show the plan and request approval.
> Once approved: run cases, capture observed behavior and approved evidence,
> record Pass/Fail/Blocked/Not Run, and draft defect reports.
> Do not run on production or invent evidence.

No staging app → all cases stay Not Run. The public TodoMVC exercise
(https://demo.playwright.dev/todomvc) is a connectivity test only.

## Stage 7 — Traceability matrix (RTM)

> Read requirements, stories, API/data requirements, actual issue keys /
> card IDs / sheet rows, UAT cases and execution records.
> Create traceability/rtm.md.
> Include BR, FR, NFR/API/DATA, US, issue key, AC, TC, execution status,
> evidence, defect and source.
> Find orphan requirements, uncovered tests, broken links, unapproved scope
> and unsupported status claims.
> Do not manufacture issue keys or evidence.

See `traceability/rtm.sample.md` for shape and a gap-report example.

## Stage 8 — Independent quality review

Run this in a **fresh session or a different agent** than produced the work:

> Act as an independent Senior BA quality reviewer.
> Review the original sources and all generated artifacts.
> Identify unsupported requirements, missing business rules, contradictions,
> scope changes, non-INVEST stories, untestable AC, API assumptions,
> incorrect SQL conclusions, missing UAT coverage, broken traceability and
> unsupported Pass claims.
> For every finding provide ID, severity, exact location, evidence, impact,
> corrective action, owner and status.
> Mark each artifact Ready / Ready with Conditions / Rework.
> Do not change files without approval.

Record results with `validation/report-template.md`.

---

## The four approval gates

| Gate | Owner action |
|---|---|
| 1. Requirements baseline | Validate scope, source evidence, open rules, priorities |
| 2. Publication | Approve content and destination before any backlog write (GitHub/Trello/Sheets/Jira) |
| 3. Interface / data | Confirm real API contract, data rules, query findings |
| 4. UAT / sign-off | Approve staging execution, inspect evidence, review traceability |

## Security & operating principles

- Fictional or explicitly permitted sanitized data only in training.
- Least-privilege service access; no secrets in prompts or repositories.
- Human approval before publishing, editing, or consequential actions.
- Source citations and actual execution evidence for every claim.
- No agent self-certifies business sign-off or UAT success.
