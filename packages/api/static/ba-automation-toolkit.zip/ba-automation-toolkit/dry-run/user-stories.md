# User Stories & Acceptance Criteria — Online Banking Address Update

| Field | Value |
|---|---|
| Artifact | Stage 2 output (`PLAYBOOK.md` § Stage 2) |
| Version | v0.1 — **DRAFT. All criteria draft until stakeholders confirm exact business and technical behaviour** |
| Date | 2026-11-01 |
| Input | `requirements/requirements-register.md` v0.1 + `requirements/clarification-log.md` v0.1, as assessed in `validation/requirements-review.md` v0.1 |
| Gate state inherited | ⛔ Checkpoint 1 **not passed** (F-001): scope unsigned, no priorities set, rules undefined. No story in this file may be committed to a sprint |
| Original sources (transitive) | `input/meeting-notes.md` (`mn`), `input/scope.md` (`sc`) — every claim below ultimately cites one of these two files |
| Not read | `stories/user-stories.sample.md` and all other `*.sample.md` (blind run) |

## 0. Conventions

- **Story IDs** `US-00x`; epic IDs `EP-0x` (container IDs — AGENTS.md rule 3 reserves `BR/FR/NFR/API/DATA/US/TC` for requirements, stories and tests).
- Each story lists **linked requirement IDs** with the register's own status. A story never upgrades a status: `Proposed` in the register stays `Proposed` here.
- **AC status**: `Confirmed AC` (derived only from a Confirmed requirement), `Draft AC` (derived from a Proposed requirement — awaiting owner confirmation), `Blocked AC` (the behaviour is not defined in any source; the AC is left as a placeholder, **not invented** — AGENTS.md rule 1).
- **Ordering is by dependency, not priority.** No source ranks anything (`clarification-log.md` header, review F-006); a priority column would be fabrication.

**Definition of Ready (analyst-proposed — no DoR exists in the sources).** A story is *Ready* only if all seven hold:

| # | Condition |
|---|---|
| DoR-1 | Traceable to cited requirement IDs |
| DoR-2 | Every linked requirement is **Confirmed** (or its Proposed status is explicitly accepted by the owning stakeholder) |
| DoR-3 | Every AC is testable without a business rule that is still undefined |
| DoR-4 | Dependencies identified and not blocking delivery of the AC |
| DoR-5 | No **gating** open question covers the story's core behaviour |
| DoR-6 | Fits in one iteration (size judgment is the analyst's — no velocity data exists in sources) |
| DoR-7 | Scope signed off by the Product Owner (Gate 1) |

---

## EP-01 — Secure self-service mailing address change

Epic goal: BR-001 (`mn:3-5`, `mn:30` "Online address change \| Confirmed business objective") with BR-002 (`mn:5`) as its quality constraint.
Roles available in the sources: **authenticated online banking customer** (`mn:3-4`) — no other persona is evidenced. Contact-centre agent is current-state only (`mn:11-12`) and has no story here (see §4).

| Story | Title | Linked requirements | Requirement status | Story status | DoR |
|---|---|---|---|---|---|
| US-001 | Only authenticated customers can enter the journey | FR-001, BR-001, NFR-001 | Confirmed / Confirmed / Confirmed-intent | Draft — closest to Ready | **Ready with conditions** |
| US-002 | See my current mailing address before changing it | FR-003, DATA-001 | Proposed / Proposed | Draft | **Not Ready** |
| US-003 | Submit a new mailing address | FR-002, FR-007, API-001 | Confirmed / Proposed / Unresolved | Draft | **Not Ready** |
| US-004 | Be told clearly whether the change succeeded or failed | FR-004, R-007 | Proposed | Draft | **Not Ready** |
| US-005 | Be asked for additional verification when it is required | FR-005 | Unresolved | **Blocked** | **Blocked** |
| US-006 | Be told what is wrong with an address I cannot submit | FR-006, DATA-002 | Unresolved / Unresolved | **Blocked** | **Blocked** |

---

## US-001 — Only authenticated customers can enter the address-change journey

**As an** authenticated online banking customer, **I want** the address-change journey to be available only after I have signed in, **so that** nobody can change my mailing address without proving who they are.

**Benefit / intent source**: `mn:17` "Authentication is required"; `mn:31` "Authentication \| Confirmed requirement"; `mn:5` "without compromising security".
**Linked requirements**: FR-001 (**Confirmed**), BR-001 (**Confirmed**), NFR-001 (**Confirmed** intent, unmeasurable — NFR-001 has no metric, review F-002).
**Depends on**: D-002 authentication capability; API-002 mechanism (**Unresolved**). **Blocks**: US-002, US-003, US-004, US-005, US-006.

### Acceptance criteria

| # | Given / When / Then | Status |
|---|---|---|
| AC-1 | **Given** a customer who is not authenticated, **when** they attempt to open the address-change journey, **then** the journey is not made available to them | **Confirmed AC** — FR-001 |
| AC-2 | **Given** a customer who is not authenticated, **when** they attempt to view the current address or submit a new address, **then** neither action is performed | **Confirmed AC** — FR-001 + `mn:31`; note: *denied* is required, *how* (redirect, error, message) is not stated → Q-013 |
| AC-3 | **Given** an authenticated customer with a valid session, **when** they open the journey, **then** they reach the address-change steps | **Confirmed AC** — FR-001 |
| AC-4 | **Given** a customer whose session has ended before they submit, **when** they submit, **then** `[blocked — behaviour not defined in sources]` | **Blocked AC** → Q-013 |
| AC-5 | **Given** a step-up verification decision is required for this change, **when** the customer proceeds, **then** `[blocked — open decision]` | **Blocked AC** → FR-005, Q-003 (owned by US-005) |

### Scenarios

| Type | Scenario | State |
|---|---|---|
| Positive | Authenticated customer reaches the journey | Specified (AC-3) |
| Negative | Unauthenticated direct attempt at the journey URL/action → refused, nothing read or written | Specified (AC-1, AC-2) |
| Negative | Unauthenticated attempt to read the current address | Specified (AC-2) |
| Boundary | Session valid at page load, expired at submit | **Blocked** — Q-013 |
| Boundary | Session at the exact moment of expiry / concurrent change from another device | **Blocked** — Q-013 |

### INVEST

| I | N | V | E | S | T |
|---|---|---|---|---|---|
| ✓ Access control is agreed, method negotiable | ~ Bundles auth only; step-up split into US-005 to keep it independent | ✓ Protects the customer's address; supports NFR-001 | ~ Estimable only once API-002 / existing platform auth is known (Q-013) | ✓ One journey gate, one iteration | ✓ AC-1–AC-3 are black-box testable today |

### Definition of Ready

DoR-1 ✓ · DoR-2 ✓ (FR-001, BR-001 Confirmed) · DoR-3 ✓ for AC-1–3 (AC-4/5 held by other stories' questions) · DoR-4 ✓ auth exists as a dependency, not a blocker for AC-1–3 · DoR-5 ✓ no gating question covers the *obligation*; Q-013 covers the *mechanism* · DoR-6 ✓ · DoR-7 ✗ (scope unsigned, F-001)

**Verdict: Ready with Conditions** — conditions: Gate 1 sign-off (D-005); Q-013 answered before implementation/design, and Q-011 if the AC is to assert *how strongly* the customer is verified (NFR-001 is currently unmeasurable, F-002).

---

## US-002 — See my current mailing address before changing it

**As an** authenticated online banking customer, **I want** to see the mailing address you currently hold for me, **so that** I can confirm what needs changing before I type a new one.

**Benefit / intent source**: `mn:14` "Display the current address"; `sc:3` "current-address display".
**Linked requirements**: FR-003 (**Proposed** — `mn:32` "Requested, awaiting formal confirmation"), DATA-001 (**Proposed** inference, review F-005).
**Depends on**: US-001; D-004 system of record (**Unresolved**, Q-006). **Blocks**: US-003 (submit-without-display flow is an open alternative, Q-001).

### Acceptance criteria

| # | Given / When / Then | Status |
|---|---|---|
| AC-1 | **Given** an authenticated customer, **when** the journey is opened, **then** the current mailing address held for that customer is displayed | **Draft AC** — FR-003 is Proposed; the display requirement itself is not yet confirmed (Q-001) |
| AC-2 | **Given** the address is displayed, **when** the customer views it, **then** `[blocked — masking/completeness not defined]` | **Blocked AC** → Q-006 |
| AC-3 | **Given** no address is held for the customer, **when** the journey is opened, **then** `[blocked — not defined in sources]` | **Blocked AC** → Q-009 |
| AC-4 | **Given** the displayed address is known to be wrong, **when** the customer wants it corrected, **then** `[blocked — not defined in sources]` | **Blocked AC** → Q-009 |

### Scenarios

| Type | Scenario | State |
|---|---|---|
| Positive | Customer sees the address on record and proceeds | Draft (AC-1) |
| Negative | Address record absent or unreadable | **Blocked** — Q-006, Q-009 |
| Boundary | Very long / multi-line / non-Latin-character address; partial or masked display | **Blocked** — Q-002, Q-006 |

### INVEST

| I | N | V | E | S | T |
|---|---|---|---|---|---|
| ✓ Negotiable | ~ Value is asserted by one stakeholder only (`mn:14`), not confirmed (R-009) | ✓ Reduces wrong-field edits vs phone process | ✗ Not estimable until the system of record is known (Q-006) | ✓ Single screen element | ✗ Not testable until masking and no-address behaviour exist |

### Definition of Ready

DoR-1 ✓ · DoR-2 ✗ (FR-003 Proposed, `mn:32`) · DoR-3 ✗ (AC-2–AC-4 blocked) · DoR-4 ✗ (D-004 unresolved) · DoR-5 ✗ (Q-001, Q-006 are gating for its core behaviour) · DoR-6 ✓ · DoR-7 ✗

**Verdict: Not Ready.** **Needs stakeholder review:** whether display is required at all (S-01/S-03, Q-001) and whether the full address may be shown to a signed-in customer (S-04, Q-006).

---

## US-003 — Submit a new mailing address

**As an** authenticated online banking customer, **I want** to submit a new mailing address through the journey, **so that** I can change it myself instead of calling the contact centre.

**Benefit / intent source**: `mn:9` "Customers should change their mailing address online"; `mn:14-15` "let customers submit a new one"; `mn:30`; `mn:3-5` "instead of calling the contact centre".
**Linked requirements**: FR-002 (**Confirmed** capability), FR-007 (**Proposed** — address of record updated), API-001 (**Unresolved** contract), DATA-001/DATA-002, NFR-002 (**Confirmed** intent, unmeasured).
**Depends on**: US-001; D-001 API contract (`mn:20-21` "its contract is not confirmed"); D-003 validation rules (`mn:34` "Not defined"); decision on immediate vs reviewed application (Q-010, review F-008).

### Acceptance criteria

| # | Given / When / Then | Status |
|---|---|---|
| AC-1 | **Given** an authenticated customer in the journey, **when** they enter a new mailing address and submit it, **then** the request is accepted for processing | **Confirmed AC** — FR-002. Validity is undefined, so the criteria for a rejected address sit in US-006 (Q-002) |
| AC-2 | **Given** an accepted request, **when** processing completes successfully, **then** the customer's mailing address of record is updated | **Draft AC** — FR-007; blocked on API-001 (Q-004) and Q-010 (immediate vs after review) |
| AC-3 | **Given** a submitted address that does not satisfy the required rules, **when** the customer submits, **then** `[blocked — rules "Not defined", mn:34]` | **Blocked AC** → US-006, Q-002 |
| AC-4 | **Given** the update service is unavailable or its result is unknown, **when** the customer submits, **then** `[blocked — error handling "Not verified", mn:35]` | **Blocked AC** → Q-004, Q-005 |
| AC-5 | **Given** the customer submits the same address already on record, **when** the submission is processed, **then** `[blocked — not defined in sources]` | **Blocked AC** → Q-002/Q-005 |
| AC-6 | **Given** the customer submits twice in quick succession, **when** both requests are processed, **then** `[blocked — idempotency unknown, mn:35]` | **Blocked AC** → Q-004 |

### Scenarios

| Type | Scenario | State |
|---|---|---|
| Positive | New address that satisfies the rules is submitted and processed | Draft (AC-1, AC-2); the rules that make an address acceptable do not exist in the sources (Q-002) |
| Negative | Submission without authentication | Specified via US-001 AC-2 |
| Negative | Service failure mid-update | **Blocked** — Q-004, Q-005 |
| Negative | Required field empty / whitespace only | **Blocked** — Q-002 |
| Boundary | Maximum and minimum address length; special characters; non-domestic format | **Blocked** — Q-002 |
| Boundary | Unchanged address; duplicate submission; submission during session expiry | **Blocked** — Q-002, Q-004, Q-013 |

### INVEST

| I | N | V | E | S | T |
|---|---|---|---|---|---|
| ✓ | ~ Validation (US-006) and outcome messaging (US-004) deliberately split out | ✓ Core of BR-001; removes a call (BR-002) | ✗ Cannot be estimated — API contract unverified (R-001) and no rules (R-002); validation UI + integration + error path is too big to be one story as it stands | ✗ Will need splitting once rules and contract arrive | ✗ Only AC-1 is testable; AC-2–AC-6 blocked |

### Definition of Ready

DoR-1 ✓ · DoR-2 ✗ (FR-007 Proposed, API-001 Unresolved) · DoR-3 ✗ (AC-3–AC-6 blocked) · DoR-4 ✗ (D-001, D-003 blocking) · DoR-5 ✗ (Q-002, Q-004 gating) · DoR-6 ✗ · DoR-7 ✗

**Verdict: Not Ready.** **Needs stakeholder review:** Q-002 (validation rules), Q-004 (contract), Q-010 (immediate vs reviewed application — F-008 calls this the largest undetermined design fork).

---

## US-004 — Be told clearly whether my change succeeded or failed

**As an** online banking customer who submitted an address change, **I want** an unmistakable statement of the outcome, **so that** I know whether I still need to call the contact centre.

**Benefit / intent source**: `mn:23-24` "We must clearly distinguish successful and failed changes"; `sc:4-5` "error handling" (Proposed).
**Linked requirements**: FR-004 (**Proposed**), R-007 (**Med** — outcome set beyond success/failure undefined).
**Depends on**: US-003; Q-005 outcome set; Q-004 error semantics. **Blocks**: UAT expected-result wording (Stage 6).

### Acceptance criteria

| # | Given / When / Then | Status |
|---|---|---|
| AC-1 | **Given** a submitted request, **when** processing ends, **then** the customer is shown an outcome that identifies it as successful or failed and the two are visibly distinguishable | **Draft AC** — the need is stated as a "must" by S-02 but has no decision-log row (R-009) |
| AC-2 | **Given** a failed change, **when** the failure is shown, **then** `[blocked — message content, channel and reference not defined]` | **Blocked AC** → Q-005 |
| AC-3 | **Given** a request whose result is not yet known, **when** the customer looks at the journey, **then** `[blocked — no intermediate state named in sources]` | **Blocked AC** → Q-005, R-007 |
| AC-4 | **Given** a successful change, **when** the customer re-opens the journey, **then** the displayed address reflects the outcome | **Draft AC** — depends on FR-003 (Proposed) and Q-001 |

### Scenarios

| Type | Scenario | State |
|---|---|---|
| Positive | Clear success shown after update | Draft (AC-1) |
| Negative | Clear failure shown with reason | **Blocked** — Q-005 |
| Boundary | Outcome after timeout / unknown result / re-entry to the journey | **Blocked** — Q-005, Q-004 |

### INVEST

| I | N | V | E | S | T |
|---|---|---|---|---|---|
| ✓ | ✓ Single concern | ✓ Avoids repeat calls and customer uncertainty (BR-002) | ~ Cheap once messages are defined | ✓ | ✗ Not testable: "clearly" has no definition and the outcome set is open (F-009) |

### Definition of Ready

DoR-1 ✓ · DoR-2 ✗ (FR-004 Proposed) · DoR-3 ✗ (AC-2/AC-3 blocked) · DoR-4 ~ · DoR-5 ✗ (Q-005) · DoR-6 ✓ · DoR-7 ✗

**Verdict: Not Ready.** **Needs stakeholder review:** Q-005 — the complete outcome list (success/failure only, or also in-progress, partial, review-required) and what "clearly distinguish" means in practice (S-02).

---

## US-005 — Be asked for additional verification when it is required  ⛔ BLOCKED

**As an** online banking customer changing my address, **I want** to be asked for extra verification when the change needs it, **so that** my address is not changed by someone who merely knows my password.

**Intent source**: `mn:17-18` "extra verification **may be** needed"; `mn:33` "Additional verification \| Open decision".
**Linked requirements**: FR-005 (**Unresolved**), NFR-001 (**Confirmed** intent), A-03.
**Depends on**: US-001; D-007 current phone verification standard (`mn:11-12`, not documented).

### Acceptance criteria

**None written.** FR-005 is an open decision: whether step-up verification applies at all, to which changes, with which factors, and whether it must match or replace the agent's phone check are all undefined (`mn:18`, `mn:33`). Writing example criteria would invent a security rule, which AGENTS.md rule 1 forbids. The story is kept as a **placeholder with ID and traceability** so the decision is not lost.

| Type | Scenario | State |
|---|---|---|
| Positive / Negative / Boundary | All | **Blocked** — Q-003 |

### INVEST

Not assessable — V and T cannot be judged for a behaviour that does not yet exist. I, N, E, S blocked with Q-003.

### Definition of Ready

DoR-1 ✓ · DoR-2 ✗ · DoR-3 ✗ · DoR-4 ✗ (D-007 undocumented) · DoR-5 ✗ (Q-003 is a **gating** question) · DoR-6 ✗ · DoR-7 ✗

**Verdict: Blocked.** Must not enter a sprint. **Owner of the unblocking decision: S-04 Security Representative (Q-003), with Q-011 for the measurable security baseline.**

---

## US-006 — Be told what is wrong with an address I cannot submit  ⛔ BLOCKED

**As an** online banking customer, **I want** to be told which part of the address I entered is not acceptable, **so that** I can fix it rather than abandon the journey and call.

**Intent source**: `mn:34` "Address validation rules \| Not defined" (named as an open item); `mn:5` "without compromising ... accuracy" (why it matters); `sc:4-5` "error handling" (Proposed).
**Linked requirements**: FR-006 (**Unresolved** placeholder, review F-004), DATA-002 (**Unresolved** — no field list exists), NFR-002.
**Depends on**: US-003; D-003 validation rules with **no named owner in the sources** (F-007).

### Acceptance criteria

**None written.** No address field list, format, length, character set, country coverage or PO-box rule appears anywhere in `input/` (F-004). Every candidate AC — "invalid postcode is rejected", "minimum one line required" — would be an invented business rule.

| Type | Scenario | State |
|---|---|---|
| Positive / Negative / Boundary | All | **Blocked** — Q-002 |

### INVEST

Not assessable for the same reason as US-005. Note also that this story cannot be *Small* until the rule set size is known (Q-002).

### Definition of Ready

DoR-1 ✓ · DoR-2 ✗ · DoR-3 ✗ · DoR-4 ✗ (D-003 has no owner) · DoR-5 ✗ (Q-002 is a **gating** question) · DoR-6 ✗ · DoR-7 ✗

**Verdict: Blocked.** **Owner of the unblocking decision: not named in the sources — the validation-rule authority must be identified first (F-007 / Q-002).**

---

## 1. Traceability — requirement → story

| Requirement | Status | Story | Uncovered by any story |
|---|---|---|---|
| BR-001 | Confirmed | US-001, US-002, US-003 | No |
| BR-002 | Confirmed intent | US-003, US-004 | Benefit not measurable (Q-008) — no test can prove it |
| FR-001 | Confirmed | US-001 | No |
| FR-002 | Confirmed | US-003 | No |
| FR-003 | Proposed | US-002 | No |
| FR-004 | Proposed | US-004 | No |
| FR-005 | Unresolved | US-005 (Blocked) | Behaviour itself |
| FR-006 | Unresolved | US-006 (Blocked) | Rules themselves |
| FR-007 | Proposed | US-003 AC-2 | Contract |
| FR-008 | Unresolved | **No story — deliberate** (see §3) | Yes |
| NFR-001 | Confirmed intent | US-001 (constraint) | Measurable target (Q-011) |
| NFR-002 | Confirmed intent | US-003/US-006 (constraint) | Measurable target (Q-011) |
| NFR-003 | Unresolved | No story | Yes — blocked by Q-007 |
| API-001 | Unresolved | US-003 dependency | Yes — Stage 5 owns it |
| API-002 | Unresolved | US-001 dependency | Yes — Q-013 |
| DATA-001 | Proposed | US-002, US-003 | System of record (Q-006) |
| DATA-002 | Unresolved | US-006 (Blocked) | Yes |
| DATA-003 | Unresolved | No story | Yes — blocked by Q-007 |
| DATA-004 | Unresolved | No story | Yes — Q-009 |

## 2. Definition of Ready — summary

| Story | Verdict | Blocking DoR items |
|---|---|---|
| US-001 | **Ready with Conditions** | DoR-7 (Gate 1 unsigned); conditions: Q-013, Q-011 |
| US-002 | **Not Ready** | DoR-2, DoR-3, DoR-4, DoR-5, DoR-7 |
| US-003 | **Not Ready** | DoR-2, DoR-3, DoR-4, DoR-5, DoR-6, DoR-7 |
| US-004 | **Not Ready** | DoR-2, DoR-3, DoR-5, DoR-7 |
| US-005 | **Blocked** | DoR-2…DoR-7 |
| US-006 | **Blocked** | DoR-2…DoR-7 |

**No story fully meets the DoR.** US-001 is one Gate-1 signature away. This is the expected consequence of Checkpoint 1 failing (`validation/requirements-review.md` F-001), not a defect in story writing.

## 3. Stories deliberately NOT written

Recorded so the omission is visible rather than silent. Each is blocked by an open question; writing one would create behaviour no source supports (AGENTS.md rule 1).

| Candidate story | Why not written | Unblocks |
|---|---|---|
| "Have my change recorded for audit" | `sc:5` scopes **audit-requirement discovery**, not an audit requirement; `mn:36` "Audit retention policy \| Not defined". FR-008 is a placeholder (F-004) | Q-007 (+ owner unnamed, F-007) |
| "Receive a confirmation notification of my new address" | No source mentions any notification channel; `mn:23-24` covers only what the customer is *shown* in the journey | Q-015, Q-005 |
| "See my change take effect immediately" | Immediate vs reviewed application is undecided; `mn:5` says "Reduce manual handling" — reduction, not elimination | Q-010 (F-008) |
| "Change my email or phone" / "Request a branch visit" / "Migrate many addresses" | Explicitly Proposed out of scope, `sc:7-8` | Q-015 confirmation only |
| "Contact-centre agent handles a fallback request" | Agent process is current-state context (`mn:11-12`); S-07 was not represented in elicitation (R-008) | Q-012 |
| Any story asserting performance, accessibility or availability behaviour | No source states any such target (§5 of the register) | Q-014, Q-011 |

## 4. Unconfirmed behaviours flagged for stakeholder review

Everything marked **Draft AC** or **Blocked AC** above is unconfirmed. Consolidated ask list, in the order that unblocks the most stories:

1. **S-01 Product Owner** — sign off scope and the unaddressed boundaries (Q-015, Q-001). Unblocks DoR-7 for all six stories and the FR-003/FR-002 decision for US-002.
2. **S-01 + S-02** — immediate application vs manual review (Q-010). Largest design fork; changes US-003, US-004, US-005.
3. **S-04 Security Representative** — is step-up verification required and to what standard (Q-003, Q-011, Q-013). Unblocks US-005, firms US-001.
4. **Validation-rule authority — must be named first** (Q-002, F-007). Unblocks US-006 and makes US-003 estimable.
5. **S-05 Integration Lead** — real Customer Profile API contract, error semantics, idempotency (Q-004). Unblocks US-003 AC-2/AC-4/AC-6 and Stage 5.
6. **S-02 Operations Manager** — complete outcome set and message wording (Q-005). Unblocks US-004.
7. **S-09 / system-of-record owner — must be named** (Q-006). Unblocks US-002 and DATA-001.
8. **Priorities** — the register and these stories carry no priority because no source assigns one (F-006). Stakeholders must set them before any sprint ordering.

## 5. Integrity statement

- No requirement, rule, field, endpoint, message, metric, priority, test result or link was invented. Blocked ACs are left empty with the reason and the question that owns the decision.
- No external system was written to. No test was executed: **TC status = Not Run** (no UAT pack exists yet; Stage 6 owns it, and it requires approved staging — `PLAYBOOK.md:107-118`).
- Stage 2 was run in the **same session** as Stage 1. The independent check required by `PLAYBOOK.md:135-137` has **not** been performed on this file.
