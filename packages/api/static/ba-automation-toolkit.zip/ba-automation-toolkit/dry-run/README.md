# Dry-Run: real Stage 1–2 output (blind agent, 2026-11-01)

These are the **actual, unedited** artifacts produced by a fresh-context AI
agent given only this repo, the `AGENTS.md` rules and the Stage 1–2 prompts in
`PLAYBOOK.md`. It could not see the `*.sample.md` files or the source guide.

Use them in teaching as ground truth for "what a good run looks like" —
and as an exercise: ask students to find the one deliberate difference between
this run and the samples (hint: counts and IDs don't match).

## What to point students at

- `requirements-register.md` — every ID-bearing row cites `file:line` + exact
  quote; three roles (compliance, system-of-record, validation-rule owner)
  recorded as **absent from sources** rather than guessed; FR-006/FR-008 exist
  only as traceable placeholders so no invented rule enters the baseline.
- `user-stories.md` — Blocked acceptance criteria left literally empty with
  the owning question, because writing plausible AC would fabricate behaviour;
  US-005/US-006 kept as ID-carrying placeholders; §3 lists stories
  **deliberately not written**, so omissions are visible.
- `requirements-review.md` — the run declares **Checkpoint 1 NOT passed**
  (unsigned scope, no priorities, 7 gating questions) instead of certifying its
  own work. That self-restraint is the whole lesson.
- Priorities are absent everywhere — the meeting notes never state any, so a
  priority column would have been fabrication.

## Honest limits of this example

- Stage 2 was run in the same session as Stage 1; the independent review
  (Stage 8, fresh context) was not performed on these files.
- Statuses are Not Run by definition — nothing was published or executed.
