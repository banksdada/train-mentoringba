# Clarification Log — Online Banking Address Update

| Field | Value |
|---|---|
| Artifact | Stage 1 output (`PLAYBOOK.md` § Stage 1) |
| Version | v0.1 — 2026-11-01 |
| Sources | `input/meeting-notes.md` (`mn`), `input/scope.md` (`sc`) |
| Status of all items | **Open** — no answer exists in the sources. No answer below has been assumed or invented (AGENTS.md rule 1) |

**Priority is analyst-proposed.** Neither source assigns any priority or ranking to any item → see F-006 in `validation/requirements-review.md`.

**Gating = must be answered before Checkpoint 1 (requirements baseline approval).**

| ID | Question | Why it matters (linked IDs) | Owner | Priority | Gating | Status | Answer |
|---|---|---|---|---|---|---|---|
| Q-001 | Is `mn:14` "Display the current address" formally confirmed, and does the confirmed journey include display **and** submission, or submission only? | FR-002, FR-003; `mn:32` "Current address display \| Requested, awaiting formal confirmation"; `sc:3` | S-01 Product Owner (scope approver, `sc:10-11`) | High | Yes | Open | — |
| Q-002 | What are the address validation rules — fields, format, allowed character sets, length limits, country/region coverage, PO boxes, and who owns the rule set? | FR-006, NFR-002, DATA-002, D-003, R-002; `mn:34` "Address validation rules \| Not defined" | **Not named in sources** — must be assigned | High | Yes | Open | — |
| Q-003 | Is additional verification beyond authentication required, in which circumstances, with which factors, and does it replace or match the agent's phone identity check? | FR-001, FR-005, NFR-001, A-03, D-007, R-003; `mn:17-18` "extra verification **may** be needed"; `mn:33` "Open decision"; `mn:11-12` | S-04 Security Representative | High | Yes | Open | — |
| Q-004 | Does the Customer Profile API support address update, and can the OpenAPI/Swagger contract be provided (endpoint, method, fields, auth, response codes, errors, timeouts, retry, idempotency)? Which environment is available for testing? | API-001, API-002, FR-007, D-001, R-001, A-04; `mn:20-21` "might support updates; its contract is not confirmed"; `mn:35` "Not verified" | S-05 Integration Lead | High | Yes | Open | — |
| Q-005 | Which outcomes must the customer be shown — success and failure only, or also in-progress/partial/review-required states — and what does "clearly distinguish" mean (message, channel, timing, reference number)? | FR-004, DATA-003, R-007; `mn:23-24` "We must clearly distinguish successful and failed changes" | S-02 Operations Manager | High | No | Open | — |
| Q-006 | Which system is the source of truth for the current mailing address, is it single-valued, and may the customer see it in full (masking/partial display)? | FR-003, FR-007, DATA-001, A-01, D-004; `mn:12` "updates the profile", `mn:14` "Display the current address" — the system is never named | **Not named in sources** — must be assigned | High | Yes | Open | — |
| Q-007 | What audit record must be kept for each address-change request and outcome, for how long, and who owns retention? | FR-008, NFR-003, DATA-003, D-006, R-005; `mn:36` "Audit retention policy \| Not defined"; `sc:5` "audit-requirement discovery" | **Not named in sources** — `sc:5` only puts *discovery* of this in scope | Medium | Yes | Open | — |
| Q-008 | What is the current contact-centre call volume for address changes, what reduction is targeted, and over what period? | BR-002, A-002, D-008, R-006; `mn:5` "Reduce manual handling"; `mn:37` "Call reduction target \| Not measured" | S-01 Product Owner | Medium | No | Open | — |
| Q-009 | What is the quality of existing stored addresses (stale, incomplete, undeliverable), and what happens when the displayed current address is visibly wrong? | FR-003, DATA-004; relevance anchored in `mn:5` "without compromising security or accuracy" — **no statement in sources** on data quality | S-02 / S-09 (S-09 not named) | Low | No | Open | — |
| Q-010 | Is an accepted change applied immediately, or routed for manual review? Does the reduction of manual handling still leave any review in place? | FR-002, FR-007, BR-002, §8 boundary gap; `mn:5` says "Reduce manual handling" — reduction, not elimination | S-01 with S-02 | High | No | Open | — |
| Q-011 | What measurable security and accuracy baselines must the online journey meet ("without compromising"), and against what are they judged? | NFR-001, NFR-002, A-03, R-002; `mn:5` states intent with no metric or standard | S-04 with S-02 | High | No | Open | — |
| Q-012 | Should contact centre agents (whose call-based process is displaced) be represented in review, and what is the fallback path when the online journey fails? | S-07, §8 boundary gap, R-008; `mn:11-12`, `mn:3-5` | S-02 Operations Manager | Medium | No | Open | — |
| Q-013 | What authentication mechanism and session rules apply (re-authentication before submit, session timeout, supported channels/devices, MFA already in place)? | FR-001, API-002, D-002; `mn:17` states the obligation only | S-04 Security Representative | Medium | No | Open | — |
| Q-014 | Which non-functional expectations apply at all — performance, availability, capacity, accessibility, privacy, international address formats? None are stated in the sources. | NFR-001…NFR-003, register §5 gap list; `mn:5` is the only quality wording and gives no metric — **no statement in sources** for the categories listed | S-01 with S-04, S-05 | Medium | No | Open | — |
| Q-015 | Does the Product Owner confirm the in-scope list and the out-of-scope list, and rule on the unaddressed boundaries (notification, international/multiple/proxy addresses, downstream mail delivery)? | §8 Scope, BR-001, R-004; `sc:3-8` is "Proposed" and `sc:11-12` "Nothing in this file is confirmed until signed off" | S-01 Product Owner | High | Yes | Open | — |

## Wording ambiguities recorded for stakeholders

These are quotes whose meaning the sources do not settle. They are not resolved by the analyst.

| Quote | Source | Ambiguity | Feeds |
|---|---|---|---|
| "extra verification **may be** needed" | `mn:17-18` | Conditional; not a requirement yet | Q-003 |
| "**might** support updates; its contract is not confirmed" | `mn:20-21` | Existence of an update capability is a hypothesis | Q-004 |
| "audit-**requirement discovery**" | `sc:5` | Discovery activity in scope ≠ audit requirement in scope | Q-007 |
| "**Reduce** manual handling" | `mn:5` | Degree unspecified; does not say eliminate | Q-008, Q-010 |
| "clearly distinguish successful and failed changes" | `mn:23-24` | No definition of "clearly", no message set, no completeness of the outcome list | Q-005 |
| "service integration" | `sc:4` | Never linked by name to the Customer Profile API | A-04, Q-004 |
| "Requested, awaiting formal confirmation" | `mn:32` | A stakeholder request in the transcript did not become a decision — the same could happen to `mn:14`/`mn:23` items | Q-001, R-009 |

## Reconciliation rules applied

1. Where the transcript and the decision log disagree in strength, the **decision log wins** — it is the only record of what was decided (`mn:26-37`). Example: display was requested at `mn:14` but `mn:32` keeps it "Requested, awaiting formal confirmation", so FR-003 is Proposed, not Confirmed.
2. Where `input/scope.md` conflicts in strength with a decision-log row, the decision log states a confirmed *objective* while scope states *proposed scope* — different objects, so both are recorded and the stronger label is never extended to detail. `sc:11-12` is honoured for all scope rows.
3. Nothing absent from the sources was added as a requirement. Absent topics are recorded as questions (Q-009, Q-014) or scope boundary gaps (§8), never as FRs.
