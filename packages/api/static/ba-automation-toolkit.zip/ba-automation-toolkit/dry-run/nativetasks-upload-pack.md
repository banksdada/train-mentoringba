# NativeTasks upload pack — BA-Automation-Lab Sprint 1

Project name: `BA-Automation-Lab`
Paste these six titles as tasks (order = dependency). Descriptions go in each
task's notes. Statuses map: Blocked → NativeTasks "Blocked/To Do",
Ready-with-conditions → "To Do".

## Task titles (one line each)

```
US-001 Authenticated customers only can enter the address-change journey
US-002 See my current mailing address before changing it
US-003 Submit a new mailing address
US-004 Be told clearly whether my change succeeded or failed
US-005 Be asked for additional verification when required [BLOCKED: Q-003]
US-006 Be told what is wrong with an address I cannot submit [BLOCKED: Q-002]
```

## Descriptions (paste into task notes)

**US-001** — Links: FR-001, BR-001, NFR-001. DoR: Ready with conditions.
AC: Given unauthenticated, when opening journey, then not made available.
Given unauthenticated, when viewing/submitting address, then nothing read or written.
Given authenticated valid session, when opening journey, then address steps reached.
Conditions: Gate-1 sign-off; Q-013 (session mechanics) before design.

**US-002** — Links: FR-003 (Proposed), DATA-001. DoR: Not Ready.
AC: Given authenticated, when journey opens, then current mailing address displayed.
Blocked AC: masking, no-address case, wrong-address correction — Q-006/Q-009.

**US-003** — Links: FR-002, FR-007, API-001. DoR: Not Ready.
AC: Given authenticated in journey, when submitting new address, then request accepted.
AC: Given accepted request completes, when success, then address of record updated.
Blocked AC: invalid input (Q-002), service failure (Q-004/Q-005),
unchanged address, duplicate submission, session expiry (Q-004/Q-013).

**US-004** — Links: FR-004. DoR: Not Ready.
AC: Given submitted request, when processing ends, then outcome shown,
success vs failure visibly distinguishable.
Blocked AC: failure wording, intermediate states — Q-005, R-007.

**US-005** — Links: FR-005 (Unresolved). Status: BLOCKED — no AC written.
Reason: step-up verification is an open decision (Security Rep, Q-003).
Writing example criteria would invent a security rule. Placeholder kept for
traceability.

**US-006** — Links: FR-006 (Unresolved), DATA-002. Status: BLOCKED — no AC.
Reason: no validation rule exists in any source (Q-002); owner unnamed (F-007).

---

## What you are proving, step by step

1. Create project + paste tasks → each fires `task_created` on the webhook
   → event lands in `data/nativetasks-events.json` on AIOS
   (view: https://aios.webawesome.co.uk/webhook/nativetasks with dashboard login)
2. Sheet integration (if bound to this project) → rows appear in
   `mentoringba-automation-sync` → `nativetasks_assess.py --dry-run` reads them
3. Mark US-001 Done → `task_updated` webhook fires → our logger flags
   `"completed": true`
4. Run the assessor → verdict row in `AIOS_Evaluation` tab — draft, awaiting
   your Gate-4 sign-off. Nothing self-certifies.

Prerequisite: deploy the pushed AIOS code (Coolify rebuild +
NATIVETASKS_WEBHOOK_SECRET env var), or events hit a 404.
