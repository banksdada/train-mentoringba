# Requirements Register — Online Banking Address Update

| Field | Value |
|---|---|
| Artifact | Stage 1 output (`PLAYBOOK.md` § Stage 1) |
| Version | v0.1 — **DRAFT, not baselined** |
| Date | 2026-11-01 |
| Prepared by | AI agent acting as Senior Business Systems Analyst |
| Sources used | `input/meeting-notes.md`, `input/scope.md` |
| Sources excluded | `requirements/*.sample.md`, `stories/*.sample.md` (not read — blind run); `requirements/api-shape.example.json` (not read as evidence — `PLAYBOOK.md:81-83` states it "is not a contract") |
| Gate status | ⛔ Checkpoint 1 **NOT passed** — see `validation/requirements-review.md` |

## 0. How to read this register

**Status legend** (AGENTS.md rule 2 — a guess is never presented as a fact):

| Label | Meaning |
|---|---|
| **Confirmed** | A source explicitly marks it confirmed and nothing in the sources contradicts it |
| **Proposed** | Stated by a stakeholder or listed in `input/scope.md`, **not yet signed off** |
| **Unresolved** | Sources explicitly say not defined / not verified / open / not measured, or the topic is absent |

**Citation format**: `file:line` plus the exact quoted words. `mn` = `input/meeting-notes.md`, `sc` = `input/scope.md`.

Every ID-bearing row cites at least one `file:line` (AGENTS.md rule 4). Where the sources say nothing on a topic, the row cites the source that makes the topic relevant and is marked **no statement in sources** — such a row records a **gap**, is labelled **Unresolved**, and asserts no behaviour.

**ID prefixes**: requirement IDs follow AGENTS.md rule 3 (`BR`, `FR`, `NFR`, `API`, `DATA`). `Q-`, `R-`, `D-`, `A-` are log entries (questions, risks, dependencies, assumptions), **not requirements**.

**Critical framing**: `sc:11-12` — "Nothing in this file is confirmed until signed off." Every scope statement below is therefore Proposed at best. `sc:10-11` requires Product Owner approval before the baseline is accepted.

---

## 1. Business objectives (BR)

| ID | Objective | Source | Status |
|---|---|---|---|
| BR-001 | Allow authenticated customers to request mailing-address changes online instead of calling the contact centre | `mn:3-5` "Business objective: allow authenticated customers to request mailing-address changes online instead of calling the contact centre"; `mn:9` "Customers should change their mailing address online"; `mn:30` "Online address change \| Confirmed business objective" | **Confirmed** |
| BR-002 | Reduce manual handling of address changes without compromising security or accuracy | `mn:5` "Reduce manual handling without compromising security or accuracy" | **Confirmed** as intent. **Unresolved** as a measurable target — `mn:37` "Call reduction target \| Not measured" → Q-008 |

No other objective, KPI, benefit figure or target date appears in either source.

## 2. Stakeholders

| ID | Stakeholder | Role / interest | Source | Status |
|---|---|---|---|---|
| S-01 | Product Owner | Wants online self-service; **owns scope approval** | `mn:9`; `sc:10-11` "Scope decisions require approval by the Product Owner" | Confirmed |
| S-02 | Operations Manager | Owns current manual process; wants unambiguous outcomes | `mn:11-12`, `mn:23-24` | Confirmed |
| S-03 | Digital Banking Lead | Wants current address shown and new address submitted | `mn:14-15` | Confirmed |
| S-04 | Security Representative | Authentication mandatory; step-up verification undecided | `mn:17-18`, `mn:33` | Confirmed |
| S-05 | Integration Lead | Owns the unverified Customer Profile API | `mn:20-21`, `mn:35` | Confirmed |
| S-06 | Authenticated online banking customers | End users of the journey | `mn:3-4` "authenticated customers" | Confirmed |
| S-07 | Contact centre agents | Current performers of identity verification + profile update; workflow is displaced by BR-001 | `mn:11-12` "an agent verifies identity and updates the profile after a call" | Proposed (affected party, **not represented in the meeting**) → Q-012 |
| S-08 | Audit / compliance / records-retention owner | A retention decision is required, but **no such role is named in any source** | `mn:36` "Audit retention policy \| Not defined"; role absent from sources | Unresolved → Q-007 |
| S-09 | System-of-record owner for the customer address | Owns the profile/address store and its data quality; **never named** | `mn:12` "updates the profile"; owner absent from sources | Unresolved → Q-006 |
| S-10 | Authority owning the address validation rule set | Must issue the rules FR-006/US-006 depend on; **never named** | `mn:34` "Address validation rules \| Not defined"; authority absent from sources | Unresolved → Q-002 |

Named speakers: 5. Roles required to answer open decisions but absent from the sources: S-08, S-09, S-10 (see review F-007).

## 3. Current-state context (not a requirement)

| Fact | Source | Status |
|---|---|---|
| Today, address changes are handled by phone; an agent verifies identity, then updates the profile after the call | `mn:11-12` "Today an agent verifies identity and updates the profile after a call" | Confirmed (single-source statement by S-02) |

This implies an existing manual identity-verification standard exists, but **its content is not described in the sources** → Q-003.

## 4. Functional requirements (FR)

| ID | Requirement | Source | Status | Open Q |
|---|---|---|---|---|
| FR-001 | The address-change journey is accessible only to authenticated customers | `mn:17` "Authentication is required"; `mn:31` "Authentication \| Confirmed requirement"; `sc:3` "authenticated journey" | **Confirmed** | Q-013 (mechanism/session rules not stated) |
| FR-002 | An authenticated customer can submit a new mailing address through the online journey | `mn:9` "Customers should change their mailing address online"; `mn:14-15` "let customers submit a new one"; `mn:30`; `sc:3-4` "new-address submission" | **Confirmed** capability; scope sign-off pending (`sc:10-12`) | Q-001 |
| FR-003 | The journey displays the customer's current mailing address | `mn:14` "Display the current address"; `mn:32` "Current address display \| Requested, awaiting formal confirmation"; `sc:3` | **Proposed** | Q-001 |
| FR-004 | The customer is clearly shown whether the change succeeded or failed | `mn:23-24` "We must clearly distinguish successful and failed changes"; `sc:4-5` "error handling" (proposed); `mn:35` "API contract/error handling \| Not verified" | **Proposed** — outcome set beyond success/failure is undefined | Q-004, Q-005 |
| FR-005 | Additional verification beyond authentication is applied where required | `mn:17-18` "extra verification may be needed"; `mn:33` "Additional verification \| Open decision" | **Unresolved** — "may be needed", explicitly an open decision | Q-003 |
| FR-006 | A submitted address is validated against agreed address rules before acceptance | `mn:34` "Address validation rules \| Not defined" | **Unresolved** — validation is named as an open item; **no rule content exists in the sources** | Q-002 |
| FR-007 | A successful request results in the customer's mailing address of record being updated | `mn:3-4` "instead of calling the contact centre" + `mn:11-12` the phone process "updates the profile" — the online equivalent must also update it; `sc:4` "service integration" | **Proposed** — intent follows BR-001; mechanism unverified (`mn:20-21`) | Q-006, Q-010 |
| FR-008 | The change request and its outcome are recorded for audit | `sc:5` "audit-requirement discovery"; `mn:36` "Audit retention policy \| Not defined" | **Unresolved** — the sources scope *discovery* of audit requirements, not an audit requirement. Listed only to make the gap traceable | Q-007 |

FR-006 and FR-008 are deliberately worded so no invented rule is smuggled in: the requirement is that a rule must exist/be decided, not what the rule says.

## 5. Non-functional requirement candidates (NFR)

| ID | Candidate | Source | Status | Testable today? |
|---|---|---|---|---|
| NFR-001 | Security must not be weakened by moving address changes online | `mn:5` "without compromising security" | **Confirmed** intent, **no standard or baseline named** | No — Q-011 |
| NFR-002 | Address changes must not be less accurate than the current assisted process | `mn:5` "without compromising ... accuracy" | **Confirmed** intent, **no metric** | No — Q-011 |
| NFR-003 | Audit trail retention must be defined and met | `mn:36` "Audit retention policy \| Not defined"; `sc:5` | **Unresolved** | No — Q-007 |

**NFR categories with no statement at all in the sources** (recorded as gaps, not as requirements): performance/response time, availability, capacity/volume, accessibility, usability, data privacy/regulatory handling, internationalisation or address formats by country, channel fallback when the journey is unavailable. → Q-011, Q-014.

## 6. API candidates

| ID | Candidate | Source | Status |
|---|---|---|---|
| API-001 | Existing "Customer Profile API" supports address update | `mn:20-21` "An existing Customer Profile API **might** support updates; **its contract is not confirmed**"; `mn:35` "API contract/error handling \| Not verified" | **Unresolved** |
| API-002 | Authentication/session mechanism used to satisfy FR-001 | `mn:17` states the obligation only; no mechanism named in either source | **Unresolved** |

Unknown for API-001 (stated here as unknown, not assumed): endpoint, method, request/response fields, authentication, authorisation model, response codes, error semantics, timeout, retry, idempotency, rate limits, environment availability. Per AGENTS.md rule 1 **no contract is drafted in this register**. Stage 5 owns interface documentation.

## 7. Data candidates

| ID | Candidate | Source | Status |
|---|---|---|---|
| DATA-001 | A current mailing address is held per customer and is retrievable for display | Inferred from `mn:12` "updates the profile" + `mn:14` "Display the current address" | **Proposed** — inference, system of record unnamed → Q-006 |
| DATA-002 | Address field structure, formats and country coverage | No field list exists in the sources; `mn:34` rules "Not defined" | **Unresolved** → Q-002 |
| DATA-003 | Audit/retention data for address-change requests and outcomes | `mn:36` "Audit retention policy \| Not defined"; `sc:5` "audit-requirement discovery" | **Unresolved** → Q-007 |
| DATA-004 | Data quality of existing addresses shown to customers (stale, incomplete, non-deliverable) | Relevance anchored in `mn:5` "without compromising security or accuracy"; **no statement in sources** on data quality | Unresolved → Q-009 |

## 8. Scope

All scope rows are **Proposed** — `sc:1-12` is titled "Proposed Scope" and states at `sc:11-12` "Nothing in this file is confirmed until signed off".

**Proposed in scope** (`sc:3-5`):

| Item | Wording | Traceable to | Status |
|---|---|---|---|
| Authenticated journey | "authenticated journey" | FR-001 | Proposed (auth itself Confirmed by `mn:31`) |
| Current-address display | "current-address display" | FR-003 | Proposed (`mn:32` awaiting confirmation) |
| New-address submission | "new-address submission" | FR-002 | Proposed in scope file / Confirmed objective `mn:30` |
| Service integration | "service integration" | FR-007, API-001 | Proposed, contract Unresolved |
| Error handling | "error handling" | FR-004 | Proposed, `mn:35` "Not verified" |
| Audit-requirement discovery | "audit-requirement discovery" | FR-008, DATA-003 | Proposed — **discovery only**, not an audit requirement |

**Proposed out of scope** (`sc:7-8`): phone/email changes; branch requests; bulk migration. Status **Proposed** — needs PO confirmation → Q-015.

**Scope boundary — not addressed by either source, so neither in nor out** (must be decided, Q-015):
- Whether a submitted change applies immediately or after manual review (`mn:5` says "Reduce manual handling" — reduction, not elimination) → Q-010
- Customer notification/confirmation of the outcome through any channel — the sources speak only of distinguishing the change itself (`mn:23-24`)
- International addresses, business/multiple addresses, shared or proxy authority (guardian, power of attorney)
- Interaction with downstream mail/statement delivery
- Fallback path when the online journey fails or is unavailable

## 9. Assumptions (analyst, all unverified)

| ID | Assumption | Basis | If wrong | Status |
|---|---|---|---|---|
| A-01 | Mailing address is a single postal address held on the customer profile | `mn:9` "mailing address"; `mn:12` "the profile" | FR-003/FR-007 data model changes | Unverified → Q-006 |
| A-02 | The same authenticated-customer base that currently calls the contact centre will use the journey | `mn:3-5` | Benefit case (BR-002) invalid | Unverified → Q-008 |
| A-03 | Agent-performed identity verification today is the security baseline the online journey must not go below | `mn:11-12` + `mn:5` | FR-005 may need a different control set | Unverified → Q-003, Q-011 |
| A-04 | `sc:4` "service integration" refers to the Customer Profile API (`mn:20`) | Both sources, never linked explicitly | API-001 may be the wrong or only partial dependency | Unverified → Q-004 |

## 10. Risks

Severity is analyst judgment (sources assign none).

| ID | Risk | Source | Sev | Mitigation / owner |
|---|---|---|---|---|
| R-001 | Update capability depends on an API whose contract is unconfirmed; design and effort cannot be sized | `mn:20-21`, `mn:35` | High | S-05 supplies OpenAPI contract (Q-004) before Stage 5 baseline |
| R-002 | Address validation rules undefined → nothing to build, nothing to test; accuracy objective (NFR-002) unprotected | `mn:34` | High | Rules authority named and rules issued (Q-002) |
| R-003 | Additional-verification decision open → rework across FR-001/FR-002 journey and possible security exposure | `mn:17-18`, `mn:33` | High | S-04 decision (Q-003) |
| R-004 | Scope is entirely unsigned ("Nothing in this file is confirmed until signed off") → baseline cannot be approved | `sc:10-12` | High | S-01 sign-off (Checkpoint 1) |
| R-005 | Audit retention undefined → compliance exposure and rework of data design | `mn:36`, `sc:5` | Med | Retention owner identified (Q-007) |
| R-006 | No baseline or target for call reduction → success of BR-002 cannot be proven; benefit may be unclaimed | `mn:37` | Med | S-01 sets measurement (Q-008) |
| R-007 | Outcome set beyond "successful and failed" is undefined; an in-flight/partial state may exist once integration is real | `mn:23-24`, `mn:35` | Med | S-02 + S-05 define outcomes (Q-005) |
| R-008 | Contact centre agents and the fallback path are not represented in the elicitation | `mn:11-12` | Low | Add S-07 to review (Q-012) |
| R-009 | Single-source statements (S-03 display request; S-02 outcome request) carry no second confirmation, and `mn:32` shows at least one request did not become a decision | `mn:32` pattern | Low | Confirm each Proposed item with its owner |

## 11. Dependencies

| ID | Dependency | Provider | Source | Status |
|---|---|---|---|---|
| D-001 | Customer Profile API contract and update capability | S-05 Integration Lead | `mn:20-21` | Unresolved — blocks FR-007, API-001 |
| D-002 | Authentication / session capability | S-04 / platform (owner not named) | `mn:17` | Required, mechanism Unresolved |
| D-003 | Address validation rules | Authority not named in sources | `mn:34` | Unresolved — blocks FR-006 |
| D-004 | System of record and data quality of current address | S-09 (not named) | `mn:12`, `mn:14` | Unresolved — blocks FR-003 |
| D-005 | Product Owner scope approval | S-01 | `sc:10-11` | Open — blocks Checkpoint 1 |
| D-006 | Audit retention policy | S-08 (not named) | `mn:36` | Unresolved |
| D-007 | Existing agent identity-verification standard (security baseline) | S-02 Operations | `mn:11-12` | Not documented in sources |
| D-008 | Baseline call volume for benefit measurement | S-01 / Operations | `mn:37` | Not measured |

## 12. Questions requiring stakeholder answers

15 open questions are logged in `requirements/clarification-log.md` (Q-001…Q-015). None can be answered from `input/` sources. Seven are gating for Checkpoint 1: Q-001, Q-002, Q-003, Q-004, Q-006, Q-007, Q-015.

## 13. Baseline status

**Not baselined.** Confirmed items: BR-001, the intent of BR-002, FR-001, and the FR-002 capability. Everything else is Proposed or Unresolved. No priorities, no acceptance criteria, no API contract and no measurable NFR exists in the sources. See `validation/requirements-review.md` for the checkpoint assessment.
