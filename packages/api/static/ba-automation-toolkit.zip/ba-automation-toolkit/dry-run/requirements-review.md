# Requirements Review — Online Banking Address Update

| Field | Value |
|---|---|
| Artifact | Stage 1 output (`PLAYBOOK.md` § Stage 1) |
| Version | v0.1 — 2026-11-01 |
| Reviewed | `requirements/requirements-register.md` v0.1, `requirements/clarification-log.md` v0.1 |
| Original sources | `input/meeting-notes.md` (37 lines), `input/scope.md` (12 lines) |
| Reviewer | The **same session that produced the register** — this is a working self-review, **not** the Stage 8 independent review (`PLAYBOOK.md:135-137` requires a fresh context). Findings here are not a sign-off |
| Template | Columns follow `validation/report-template.md:9-11` |

---

## 1. Coverage check — did Stage 1 extract what the prompt asked?

| Stage 1 prompt item (`PLAYBOOK.md:15-25`) | Where it landed | Verdict |
|---|---|---|
| Read `input/meeting-notes.md` and `input/scope.md` | Both read in full (37 + 12 lines); no other input source exists | Met |
| Objectives | §1 (BR-001, BR-002) | Met — **complete**: no other objective appears in the sources |
| Stakeholders | §2 (S-01…S-10) | Met — 5 named speakers, 1 implied user group, 1 affected-but-unrepresented, 3 missing owners flagged |
| FRs | §4 (FR-001…FR-008) | Met |
| NFR candidates | §5 (NFR-001…NFR-003 + list of unstated categories) | Met as *candidates* — none is measurable |
| API / data candidates | §6 (API-001, API-002), §7 (DATA-001…DATA-004) | Met — no contract drafted (rule 1) |
| Scope | §8 in / out / unaddressed boundaries | Met — all rows Proposed per `sc:11-12` |
| Risks | §10 (R-001…R-009) | Met |
| Dependencies | §11 (D-001…D-008) | Met |
| Cite the exact source for every finding | §0 legend + every row | Met — see audit §2 |
| Label Confirmed / Proposed / Unresolved | Every ID'd row | Met — see tallies §3 |
| Questions requiring stakeholder answers | `clarification-log.md` Q-001…Q-015 | Met — all Open, none answered |
| No external writes | Local files only in `requirements/` and `validation/` | Met |

## 2. Evidence audit (AGENTS.md rule 4)

- Rows carrying a requirement ID: 19 (BR 2, FR 8, NFR 3, API 2, DATA 4).
- Rows with a `file:line` citation: **19/19**. Rows where the sources are silent cite the anchor that makes the topic relevant and are marked `no statement in sources` (e.g. DATA-004 → `mn:5`).
- Quotes used are verbatim from the two input files; none was paraphrased inside quotation marks.
- No URL, endpoint, field name, status code, threshold, date or owner was invented. Unknowns are listed as unknowns (§6 of the register).
- Non-requirement IDs (`Q-`, `R-`, `D-`, `A-`, `S-`) are declared as log entries in §0, keeping the rule-3 requirement namespace clean.

## 3. Status composition — how much can actually be built?

| Status | Count | Share | Items |
|---|---|---|---|
| Confirmed | 6 | 32% | BR-001, BR-002*, FR-001, FR-002*, NFR-001*, NFR-002* |
| Proposed | 4 | 21% | FR-003, FR-004, FR-007, DATA-001 |
| Unresolved | 9 | 47% | FR-005, FR-006, FR-008, NFR-003, API-001, API-002, DATA-002, DATA-003, DATA-004 |

\* Marked Confirmed but **intent-only**: the sources confirm the aim, not a buildable, testable rule (BR-002 has no target — `mn:37`; NFR-001/NFR-002 have no metric — `mn:5`).

**Actionable confirmed requirements: 3** — BR-001, FR-001, FR-002. That is the entire firm basis of this baseline.

## 4. Contradiction and consistency check

No direct contradiction exists between `input/meeting-notes.md` and `input/scope.md`. Two strength mismatches were found and handled:

1. `mn:30` marks "Online address change" a **Confirmed business objective**, while `sc:11-12` says "**Nothing in this file is confirmed until signed off**". Different objects — a decided objective versus a proposed scope file. Handling: the capability (FR-002) is Confirmed from the decision log; every scope row stays Proposed; the objective label was **not** extended to functional detail.
2. The transcript has stronger language than the decision log in two places: `mn:14` "Display the current address" (an instruction) versus `mn:32` "Requested, awaiting formal confirmation"; `mn:23-24` "We must clearly distinguish successful and failed changes" has no decision-log row at all. Handling: decision log wins (clarification-log "Reconciliation rules applied" §1), so FR-003 and FR-004 are Proposed, not Confirmed. `mn:32` is the precedent that a transcript request does not automatically become a decision — hence R-009.

Internal consistency of the register: FR↔BR, FR↔API/DATA, risk↔source and dependency↔source cross-references all resolve to IDs that exist. No duplicate or reused ID (register ID inventory: BR 001-002, FR 001-008, NFR 001-003, API 001-002, DATA 001-004, S 01-010, A 001-004, R 001-009, D 001-008, Q 001-015 — verified unique, see §8).

## 5. Findings

| ID | Sev | Location (file + line/section) | Evidence | Impact | Corrective action | Owner | Status |
|---|---|---|---|---|---|---|---|
| F-001 | High | register §13; §8 | `sc:10-12` "Nothing in this file is confirmed until signed off"; `mn:33` "Open decision"; `mn:34` "Not defined" | Checkpoint 1 requires "Stakeholder decisions exist for rules, scope and priorities before the baseline is approved" (`PLAYBOOK.md:28-29`). **Zero** of the three exist | Product Owner rules on scope (Q-015); Security on verification (Q-003); validation authority named (Q-002) before baselining | S-01 | Open |
| F-002 | High | register §5 | `mn:5` "without compromising security or accuracy" — no metric, threshold or standard anywhere in sources | No NFR can be tested or accepted; quality bar is unfalsifiable | Q-011, Q-014: obtain measurable targets or a documented decision that none apply | S-04, S-01 | Open |
| F-003 | High | register §6 | `mn:20-21` "might support updates; its contract is not confirmed"; `mn:35` "Not verified" | FR-007 depends on an unproven interface; Stage 5 has no contract to document; effort and risk unsized | Q-004: Integration Lead supplies the real OpenAPI contract; no contract drafted meanwhile | S-05 | Open |
| F-004 | Med | register §4 FR-006, FR-008 | `mn:34` "Address validation rules \| Not defined"; `mn:36` "Audit retention policy \| Not defined" | Placeholder requirements that carry an ID but no behaviour; downstream stages could treat them as decided | Keep as Unresolved; forbid story-level AC until Q-002/Q-007 answered | S-01 to assign | Open |
| F-005 | Med | register §7 DATA-001 | Inferred from `mn:12` "updates the profile" + `mn:14` "Display the current address"; **no source names the system** | If address data is not in one retrievable place, FR-003 fails or needs a new integration | Q-006 confirm system of record and retrievability | S-09 (unnamed) | Open |
| F-006 | Med | clarification-log header | `mn:28-37` decision log has no priority column; `sc:3-8` lists scope items unordered — neither source ranks or prioritises anything | Any sprint order, MVP cut or priority label in later stages would be analyst invention | Stakeholders set MoSCoW/priority at Gate 1 | S-01 | Open |
| F-007 | Med | register §2 S-08, S-09, S-10; §11 D-003, D-006 | `mn:34`, `mn:36`, `mn:12` each require an owner that no source names — three open decisions have **no named owner**: validation authority, audit/retention owner, system-of-record owner | Unowned questions will not get answered; elicitation is incomplete | Identify and invite the owners before re-running the checkpoint | S-01, S-02 | Open |
| F-008 | Med | register §8 boundary list; Q-010 | `mn:5` says "**Reduce** manual handling" — it never says eliminate; no source states whether an accepted change applies immediately or after review | The single largest design fork (straight-through vs reviewed) is undetermined; it changes FR-002, FR-007, FR-004 and the whole story set | Q-010 decision recorded in `decisions/`-style log before Stage 2 refinement | S-01 + S-02 | Open |
| F-009 | Med | register §4 FR-004; Q-005 | `mn:23-24` names exactly two outcomes; `mn:35` leaves error handling "Not verified" | AC cannot enumerate states; a pending/partial state may appear once integration is real | Q-005 define the full outcome set and wording | S-02, S-05 | Open |
| F-010 | Low | register §10 R-009 | `mn:32` proves a transcript request did not become a decision | Statements from a single speaker (S-03, S-02) may be over-weighted | Confirm each Proposed item with its originator | S-03, S-02 | Open |
| F-011 | Low | register §3, §2 S-07 | `mn:11-12` describes the agent process; its verification standard is never documented | Security baseline for NFR-001/A-03 cannot be compared; fallback path unknown | Q-003, Q-012: obtain the current phone verification standard | S-02 | Open |
| F-012 | Low | register §2 S-06 | Customer needs appear only as the PO's framing (`mn:3-5`, `mn:9`); no customer research cited | Usability/accessibility assumptions untested | Record as risk acceptance at Gate 1 or obtain customer input | S-01 | Open |
| F-013 | Low | `clarification-log.md` §status | `mn:14` "Display the current address" uses imperative wording; `sc:3` lists it in scope, but `mn:32` says awaiting confirmation | Wording reads stronger than its status; readers may over-trust | Status label retained as Proposed throughout; no rewording of evidence | Analyst | Closed — handled by reconciliation rule 1 |

## 6. Testability scan

| ID | Can a test be written today? | Blocker |
|---|---|---|
| FR-001 | Yes — access denied without authentication, granted with it | Mechanism unspecified (Q-013) does not block a black-box test |
| FR-002 | Partially — submission is accepted, but which addresses are acceptable is undefined | Q-002, Q-004 |
| FR-003 | Partially — display exists/doesn't, but masking and completeness undefined | Q-001, Q-006 |
| FR-004 | No — outcome set and message rules undefined | Q-005 |
| FR-005 | No — requirement itself is open | Q-003 |
| FR-006 | No — no rules to validate against | Q-002 |
| FR-007 | No — no interface contract | Q-004 |
| FR-008 | No — retention undefined | Q-007 |
| NFR-001/002/003 | No — no metric | Q-011, Q-007 |

## 7. Verdict and recommended next actions

**Artifact verdicts** (scale from `validation/report-template.md:13`):

- Requirements register — **Ready with Conditions**
- Clarification log — **Ready with Conditions** (conditions: assign the three ownerless questions, F-007; agree priorities, F-006)
- This review — informational; the authoritative verdict must come from the **Stage 8 independent reviewer** in a fresh context

**Conditions attached to the Ready label:**
1. C-1 — Checkpoint 1 is **not** passed and this artifact must not be baselined or published (Gate 1 owner action: `PLAYBOOK.md:156`).
2. C-2 — Only 3 of 19 requirement rows are actionable-confirmed (§3). Stage 2 output must inherit the Confirmed/Proposed/Unresolved labels and must not silently promote any of them.
3. C-3 — `sample.md` artifacts were not read; convergence with the reference examples is untested by design (blind run).
4. C-4 — FR-006 and FR-008 exist to trace open decisions; they must not be built against (F-004).

**Do next (in order):**
1. Product Owner: confirm scope in/out and rule on unaddressed boundaries — Q-015, Q-001.
2. Name the missing owners: validation authority, audit-retention owner, address system-of-record owner — F-007 / Q-002, Q-007, Q-006.
3. Security: settle step-up verification — Q-003 — and measurable security/accuracy baselines — Q-011.
4. Integration Lead: provide the Customer Profile API contract — Q-004.
5. Operations: define the outcome set and messages — Q-005 — and supply the current phone verification standard — Q-012.
6. Record each answer as a dated decision, then re-run this review with answers in place before Gate 1.

**No external writes were made. Nothing here was executed against a system; nothing is claimed as tested or verified. Status of all tests/checks: Not Run.**

## 8. Verification actually run on these artifacts (evidence)

Machine-checked on 2026-11-01 against `input/meeting-notes.md` and `input/scope.md` only:

| Check | Command basis | Result |
|---|---|---|
| Quote fidelity — every string inside `"…"` appears verbatim in the two input files (whitespace/line-wrap and markdown emphasis normalised; editorial ellipses skipped; artifact-own vocabulary excluded and listed) | python normalised substring match over both sources | **Pass** after 4 case-mismatches were corrected (A-01, A-04, Q-001, Q-010 wording) |
| Citation completeness — requirement rows carry `file:line` | regex over register table rows | **19/19** requirement rows cite `mn:`/`sc:`; 1 row (DATA-004) is gap-marked `no statement in sources` |
| Line-range validity — every `mn:N[-M]` / `sc:N[-M]` lands inside the file | regex + line count (37 / 12) | **0 out-of-range references** |
| ID uniqueness — no requirement ID defined twice, no reuse | regex over first table cell per row, per artifact | **0 duplicates**. `US-001…US-006` appear in three tables of the stories file (overview, traceability, DoR) — cross-references, not redefinitions |
| Namespace hygiene — requirement IDs limited to rule-3 prefixes | inventory | Requirements: BR 2, FR 8, NFR 3, API 2, DATA 4 (=19). Non-requirement logs: Q 15, R 9, D 8, A 4, S 10, F 13, US 6, EP 1 |
| Story ↔ requirement coverage | stories §1 traceability table | Every FR/API/DATA row resolves to a story or an explicit gap; FR-008, NFR-003, DATA-003, DATA-004 have **no story by design** and the reason is recorded |

**Not run / cannot be run here:** no browser, no API call, no database, no Jira/Confluence, no test execution. Every test-related status in these artifacts is **Not Run**. The Stage 8 independent review (fresh context) is still outstanding.
