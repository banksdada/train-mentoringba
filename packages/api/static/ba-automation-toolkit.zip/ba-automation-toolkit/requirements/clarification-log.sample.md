# Clarification Log — Online Banking Address Update

Open questions requiring stakeholder answers before the baseline is approved.

| # | Question | Owner | Blocking | Status |
|---|---|---|---|---|
| Q1 | What "extra verification" beyond authentication is required for an address change? | Security Rep | NFR-001 | Open |
| Q2 | What are the address validation rules (fields, formats, countries)? | Product Owner | DATA-001, FR-002 | Open |
| Q3 | Confirm Customer Profile API contract: endpoint, auth, error codes, idempotency. | Integration Lead | API-001, FR-003 | Open |
| Q4 | Priorities (MoSCoW) for FR-001..FR-004 were never stated in the meeting. | Product Owner | baseline | Open |
| Q5 | Audit retention policy for address_change_audit? | Compliance (not present) | NFR | Open |
| Q6 | Target % reduction in contact-centre calls (success measure)? | Operations Manager | scope | Open |
