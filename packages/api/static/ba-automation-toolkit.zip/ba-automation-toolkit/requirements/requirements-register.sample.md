# Requirements Register — Online Banking Address Update

Status: DRAFT — illustrative example generated per Stage 1. Replace with your agent's
output after BA review. Source: `input/meeting-notes.md` unless noted.

| ID | Candidate requirement | Status | Source |
|---|---|---|---|
| BR-001 | Enable online address-change requests | Confirmed objective | "Customers should change their mailing address online." (Product Owner) |
| FR-001 | Display current mailing address | Draft — Proposed | "Display the current address" (Digital Banking Lead); awaiting formal confirmation |
| FR-002 | Allow proposed address entry | Draft — Proposed | "let customers submit a new one" (Digital Banking Lead) |
| FR-003 | Send approved update request to service | Draft — Proposed; API unknown | "existing Customer Profile API might support updates" (Integration Lead) |
| NFR-001 | Apply agreed access/security controls | Unresolved — definition pending | "Authentication is required; extra verification may be needed" (Security Rep) |
| API-001 | Determine API contract and errors | Discovery — Unresolved | "its contract is not confirmed" (Integration Lead) |
| DATA-001 | Confirm address schema and validation | Discovery — Unresolved | "Address validation rules: Not defined" (decision log) |
| FR-004 | Distinguish successful vs failed changes clearly | Proposed | "We must clearly distinguish successful and failed changes." (Operations Manager) |

No item above is approved. Priorities are not set — the meeting notes do not
state them (see `clarification-log.md` Q4).
