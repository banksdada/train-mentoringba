# BA Automation Lab

A hands-on, agent-agnostic toolkit that shows a Business Analyst how to
automate the repetitive 70% of documentation work — and rigorously gate the
20% where AI hallucination would cost you. AI automates the paperwork; the BA
keeps interpretation, scope, risk and sign-off.

Built from the *Complete BA Automation Practical Guide* as a working
end-to-end workflow, using a fictional online-banking **address update** case
study. Works with any AI coding agent (Claude Code, Codex, Cursor, opencode, Gemini CLI, Copilot, etc.).

## The workflow

```
stakeholder notes ─▶ requirements register ─▶ user stories & AC
        │                     │                      │
        │              (approval gate 1)             │
        ▼                                            ▼
  SQL data validation ◀── API requirements   backlog publish (NativeTasks + Google Sheets · GitHub · Trello · Jira)
        │                                        (approval gate 2)
        ▼
  UAT (browser automation, staging only) ─▶ RTM ─▶ independent QA review
                                                 (approval gates 3 & 4)
```

Eight stages, full prompt text in [PLAYBOOK.md](PLAYBOOK.md).

## Backlog: NativeTasks + Google Sheets (recommended)

For this mentoringba setup, the backlog uses **[NativeTasks](https://nativetasks.com)** synced to **Google Sheets** (one-way out from NativeTasks). The agent writes approved stories to a shared Google Sheet; you move them to NativeTasks manually (no public API exists). Completions sync back to the sheet in real-time and can be assessed separately. See [adapters/google-sheets-nativetasks.md](adapters/google-sheets-nativetasks.md) for details.

## Try it in 3 commands (no accounts, no MCP, works offline)

```bash
git clone <this repo> && cd ba-automation-toolkit
python3 tools/init_db.py
python3 tools/run_sql_checks.py
```

Then open any AI agent (Claude Code, Codex, opencode, Cursor, Copilot,
Gemini CLI) in the folder and run Stage 1 from the playbook.

## Layout

```
AGENTS.md / CLAUDE.md          the rules every agent must follow (identical)
PLAYBOOK.md                    stages 1-8 with copy-paste prompts
SETUP.md                       per-agent installation + backend wiring
adapters/                      Stage 3 backends: GitHub Issues, Trello,
                               Google Sheets→NativeTasks, Jira/Confluence
mcp.example.json               agent-neutral MCP config (Atlassian, Playwright)
.claude|.agents/skills/…       the ba-requirements skill (both conventions)
input/                         fictional meeting notes + proposed scope
requirements/ stories/ uat/
traceability/ validation/      sample artifacts + templates for your outputs
data/                          demo SQLite dataset with planted defects
dry-run/                       real blind-agent Stage 1-2 output, annotated
tools/                         init_db.py, run_sql_checks.py (pure Python)
```

## What this deliberately does NOT do

- No invented facts. Every sample artifact cites its source and keeps
  Confirmed / Proposed / Unresolved separate.
- No fake test results. The demo data contains a planted orphan record and a
  reconciliation trap; the checks prove detection, not confidence.
- No write access without a human gate. Backlog writes and UAT execution
  only happen after explicit approval (and only in staging).
- No agent lock-in. Prompts, rules and tools are plain files. Swap Claude for
  GPT for Gemini — the gates protect you either way.

## The teaching point (for mentoringba)

The framework's value is not the prompts. It is the **error-propagation
model**: an unverified rule in meeting notes silently becomes a requirement,
then a story, then a Jira ticket, then a SQL check, then an RTM row. Each
stage's ⛔ checkpoint exists because the cost of a bad artifact grows every
time it is referenced downstream. Understand that and you can run this with
any model on any budget.

All banking data, names and systems in this repo are fictitious.
