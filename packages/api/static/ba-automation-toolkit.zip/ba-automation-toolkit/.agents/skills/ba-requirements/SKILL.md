---
name: ba-requirements
description: Extract traceable, testable BA requirements from meeting notes and scope. Use when asked to produce a requirements register, clarification log, or requirements review.
---

# BA Requirements Analysis

Read input sources (`input/meeting-notes.md`, `input/scope.md`); extract explicit requirements only.

Classify every item: **Confirmed**, **Proposed**, or **Unresolved**.

Create requirements with unique IDs (BR, FR, NFR, API, DATA) and source citations (file + quote).

Identify contradictions, risks and clarification questions.

Produce:
- `requirements/requirements-register.md`
- `requirements/clarification-log.md`
- `validation/requirements-review.md`

Rules: never invent requirements or API contracts. No external writes.
Unexecuted items stay "Not Run".
