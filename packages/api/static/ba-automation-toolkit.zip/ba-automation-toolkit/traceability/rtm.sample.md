# Requirement Traceability Matrix — Illustrative

Generated per Stage 7. Illustrative only: real RTM must be reconciled against
approved, uniquely numbered artifacts, actual issue keys and real execution
evidence. Never manufacture keys or evidence.

| BR | FR | Related | Story | Issue key | Test | Status | Evidence |
|---|---|---|---|---|---|---|---|
| BR-001 | FR-001 | — | US-001 | (none yet) | TC-001 | Not Run | — |
| BR-001 | FR-002 | DATA-001 | US-001 | (none yet) | TC-002 | Blocked | — |
| BR-001 | FR-003 | API-001 | US-001 | (none yet) | TC-004 | Not Run | — |
| BR-001 | FR-003 | NFR-001 | US-001 | (none yet) | TC-003 | Not Run | — |

Gap report: NFR-001 has no defined acceptance rule; API-001 and DATA-001 are
discovery items with no test coverage; orphan check — none of the FRs lack a
story, but none have approved status either. Baseline is not ready.
