# User Stories — Online Banking Address Update

Illustrative Stage 2 output, draft until stakeholders confirm behaviors.
Linked requirement IDs come from `requirements/requirements-register.sample.md`.

## US-001 (links FR-001, FR-002, FR-003, FR-004)

As an authenticated banking customer, I want to submit a new mailing address
so that my profile can be maintained without contacting an agent.

- AC-01: Given an authenticated customer viewing the profile, when the address
  section loads, then the current mailing address is displayed.
- AC-02: Given a new mailing address is entered, when the customer submits it,
  then required data is sent to the approved service.
- AC-03: Given confirmed service success, when the response arrives, then the
  customer sees a successful result.
- AC-04: Given the service cannot complete the request, when the response
  arrives, then the customer does not see a false success message.

Definition of Ready: NOT READY — blocked by Q1 (verification), Q2 (validation
rules), Q3 (API contract). Unconfirmed behaviours above remain draft.
