# UAT Test Cases — Online Banking Address Update

Illustrative Stage 6 pack. Execution status stays Not Run / Blocked until a
human runs it against an approved staging system with synthetic users.

| TC | Scenario | Mapped requirement | Precondition | Expected result | Status |
|---|---|---|---|---|---|
| TC-001 | Valid address submission | FR-002, FR-003 | Authenticated; Q2 rules defined | Success shown; audit row written | Not Run |
| TC-002 | Required address fields missing | FR-002, DATA-001 | Authenticated | Validation error; no partial write | Blocked: rules pending (Q2) |
| TC-003 | Unauthenticated access | NFR-001 | None | Redirect/denied; no data shown | Not Run |
| TC-004 | Downstream service failure | FR-004, API-001 | Failure fixture | Explicit failure message; no false success | Not Run |
| TC-005 | Duplicate submission | FR-003 | Idempotency policy defined | Single effective change | Blocked: policy pending (Q3) |

Evidence column: attach screenshot/log/trace IDs after a real run. Never fill
results from AI text alone.
